            
                </div>
            <footer>
                <p class="mt-5 mb-3 text-muted text-center">&copy; 2020 <a href="http://validator.w3.org/check?uri=referer"><img
      src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Strict" height="31" width="88" /></a> 
				<!--Reference for Privacy Policy Generator: https://app.termsfeed.com/ -->
				<a href="https://www.termsfeed.com/live/b6d42e2e-fa4f-4e58-81af-7b5c72204d5d" style="color:black"> Privacy Policy </a></p>
            </footer>
        </main>  
       </div>
    </div>
  </body>
</html>