<?php
/*********COOKIES*****************/
define("COOKIE_LIFESPAN", "2592000"); //NOTE: 60X60X24X7

/*********USER TYPES*****************/
define ("ADMIN", 's');
define ("AGENT", 'a');
define ("CLIENT", 'c');
define ("PENDING", 'p');
define ("DISABLED", 'd');

/*********DATABASE CONSTANTS*****************/
define ("DB_HOST", "127.0.0.1");
define ("DATABASE", "hussainin_db");
define ("DB_ADMIN", "hussainin");
define ("DB_PORT", "5432");
define ("DB_PASSWORD", "Ashraf1997");

/*********Default page CONSTANTS*****************/
define ("RECORDS_PER_PAGE" , "10");
?>